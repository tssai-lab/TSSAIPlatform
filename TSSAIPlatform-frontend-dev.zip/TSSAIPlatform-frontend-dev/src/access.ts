/**
 * 系统权限定义（基于 useAccess）
 * 角色：super_admin 超级管理员 | normal_admin 普通管理员 | user 普通用户
 */
export default function access(
  initialState: { currentUser?: API.CurrentUser } | undefined,
) {
  const { currentUser } = initialState ?? {};
  const role = currentUser?.role ?? '';

  const isSuperAdmin = role === 'super_admin';
  const isNormalAdmin = role === 'normal_admin';
  const isAdmin = isSuperAdmin || isNormalAdmin;

  return {
    /** 是否超级管理员（唯一，系统最高权限） */
    isSuperAdmin,
    /** 是否普通管理员（可管理普通用户，无角色/权限管理） */
    isNormalAdmin,
    /** 是否任意管理员（用于显示系统管理一级菜单） */
    isAdmin,

    /** 系统管理-用户管理：超管+普管可见 */
    canAccessSystemUser: isAdmin,
    /** 系统管理-管理员列表：仅超管（管理员账号属于敏感数据） */
    canAccessSystemAdmin: isSuperAdmin,
    /** 系统管理-日志管理：超管+普管可见 */
    canAccessSystemLog: isAdmin,
    /** 系统管理-系统配置：仅超管 */
    canAccessSystemConfig: isSuperAdmin,

    /** 用户管理-删除/批量删除/导出：管理员可用 */
    canUserDeleteOrExport: isAdmin,
    /** 用户管理-角色筛选与分配管理员角色：仅超管（普管指定不了管理员） */
    canUserRoleFilterAndAssignAdmin: isSuperAdmin,
    /** 日志管理-导出：管理员可用 */
    canLogExport: isAdmin,
    /** 日志管理-查看管理员日志及IP：管理员可用 */
    canLogViewAdminAndIp: isAdmin,

    /** 个人中心-我的操作记录：所有登录用户 */
    canViewMyOperationLogs: !!currentUser,
  };
}
