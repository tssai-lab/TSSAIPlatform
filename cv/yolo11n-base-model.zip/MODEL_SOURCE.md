# YOLO11n model source

- URL: https://github.com/ultralytics/assets/releases/download/v8.3.0/yolo11n.pt
- SHA-256: 0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1
- Upstream release: Ultralytics assets v8.3.0
- License: AGPL-3.0 or separately obtained Ultralytics commercial license
